/*
	BASSenc cast example
	Copyright (c) 2006-2011 Un4seen Developments Ltd.
*/

#define _GNU_SOURCE // needed for strcasestr

#include <gtk/gtk.h>
#include <glade/glade.h>
#include <glib/gthread.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "bass.h"
#include "bassenc.h"

// path to glade file
#ifndef GLADE_PATH
#define GLADE_PATH ""
#endif

GladeXML *glade;
GtkWidget *win=0;

HRECORD rchan=0;	// recording/encoding channel
HENCODE encoder;

DWORD bitrates[14]={32,40,48,56,64,80,96,112,128,160,192,224,256,320}; // available bitrates

// display error messages
void Error(const char *es)
{
	GtkWidget *dialog=gtk_message_dialog_new(GTK_WINDOW(win),GTK_DIALOG_DESTROY_WITH_PARENT,
		GTK_MESSAGE_ERROR,GTK_BUTTONS_OK,"%s\n(error code: %d)",es,BASS_ErrorGetCode());
	gtk_dialog_run(GTK_DIALOG(dialog));
	gtk_widget_destroy(dialog);
}

#define GetWidget(id) glade_xml_get_widget(glade,id)

void WindowDestroy(GtkObject *obj, gpointer data)
{
	gtk_main_quit();
}

BOOL CALLBACK RecordingCallback(HRECORD handle, const void *buffer, DWORD length, void *user)
{
	return BASS_Encode_IsActive(handle); // continue recording if encoder is alive
}

void Start();
void Stop();

// encoder death notification
void CALLBACK EncoderNotify(HENCODE handle, DWORD status, void *user)
{
	if (status<0x10000) { // encoder/connection died
		gdk_threads_enter();
		Stop(); // free the recording and encoder
		if (GTK_TOGGLE_BUTTON(GetWidget("reconnect"))->active) { // auto-reconnect...
			gtk_widget_set_sensitive(GetWidget("start"),FALSE);
			sleep(1); // wait a sec
			Start();
			gtk_widget_set_sensitive(GetWidget("start"),TRUE);
		} else {
			GtkWidget *dialog=gtk_message_dialog_new(GTK_WINDOW(win),GTK_DIALOG_DESTROY_WITH_PARENT,
				GTK_MESSAGE_ERROR,GTK_BUTTONS_OK,status==BASS_ENCODE_NOTIFY_CAST?"The server connection died!":"The encoder died!");
			gtk_dialog_run(GTK_DIALOG(dialog));
			gtk_widget_destroy(dialog);
		}
		gdk_threads_leave();
	}
}

void Start()
{
	char com[100];
	const char *server,*pass,*name,*url,*genre,*desc,*content;
	DWORD bitrate,pub;
	// start recording @ 44100hz 16-bit stereo (paused to setup encoder first)
	if (!(rchan=BASS_RecordStart(44100,2,BASS_RECORD_PAUSE,&RecordingCallback,0))) {
		Error("Couldn't start recording");
		return;
	}
	bitrate=bitrates[gtk_combo_box_get_active(GTK_COMBO_BOX(GetWidget("bitrate")))]; // get bitrate
	// setup encoder command-line (raw PCM data to avoid length limit)
	if (GTK_TOGGLE_BUTTON(GetWidget("mp3"))->active) { // MP3
		sprintf(com,"lame -r -s 44100 -b %d -",bitrate); // add "-x" for LAME versions pre-3.98
		content=BASS_ENCODE_TYPE_MP3;
	} else { // OGG
		sprintf(com,"oggenc -r -R 44100 -M %d -m %d -",bitrate,bitrate);
		content=BASS_ENCODE_TYPE_OGG;
	}
	encoder=BASS_Encode_Start(rchan,com,BASS_ENCODE_NOHEAD|BASS_ENCODE_AUTOFREE,NULL,0); // start the encoder
	if (!encoder) {
		Error("Couldn't start encoding...\n"
			"Make sure OGGENC (if encoding to OGG) or LAME (if encoding to MP3) is installed.\n");
		BASS_ChannelStop(rchan);
		rchan=0;
		return;
	}
	// setup cast
	server=gtk_entry_get_text(GTK_ENTRY(GetWidget("server")));
	pass=gtk_entry_get_text(GTK_ENTRY(GetWidget("pass")));
	name=gtk_entry_get_text(GTK_ENTRY(GetWidget("name")));
	url=gtk_entry_get_text(GTK_ENTRY(GetWidget("url")));
	genre=gtk_entry_get_text(GTK_ENTRY(GetWidget("genre")));
	desc=gtk_entry_get_text(GTK_ENTRY(GetWidget("desc")));
	pub=GTK_TOGGLE_BUTTON(GetWidget("public"))->active;
	if (!BASS_Encode_CastInit(encoder,server,pass,content,name,url,genre,desc,NULL,bitrate,pub)) {
		Error("Couldn't setup connection with server");
		BASS_ChannelStop(rchan);
		rchan=0;
		return;
	}
	BASS_ChannelPlay(rchan,FALSE); // resume recording
	gtk_button_set_label(GTK_BUTTON(GetWidget("start")),"Stop");
	gtk_widget_set_sensitive(GetWidget("server"),FALSE);
	gtk_widget_set_sensitive(GetWidget("pass"),FALSE);
	gtk_widget_set_sensitive(GetWidget("name"),FALSE);
	gtk_widget_set_sensitive(GetWidget("url"),FALSE);
	gtk_widget_set_sensitive(GetWidget("genre"),FALSE);
	gtk_widget_set_sensitive(GetWidget("desc"),FALSE);
	gtk_widget_set_sensitive(GetWidget("public"),FALSE);
	gtk_widget_set_sensitive(GetWidget("mp3"),FALSE);
	gtk_widget_set_sensitive(GetWidget("ogg"),FALSE);
	gtk_widget_set_sensitive(GetWidget("bitrate"),FALSE);
	gtk_widget_set_sensitive(GetWidget("title"),TRUE);
	BASS_Encode_SetNotify(encoder,EncoderNotify,0); // notify of dead encoder/connection
}

void Stop()
{
	// stop recording & encoding
	BASS_ChannelStop(rchan);
	rchan=0;
	gtk_button_set_label(GTK_BUTTON(GetWidget("start")),"Start");
	gtk_widget_set_sensitive(GetWidget("server"),TRUE);
	gtk_widget_set_sensitive(GetWidget("pass"),TRUE);
	gtk_widget_set_sensitive(GetWidget("name"),TRUE);
	gtk_widget_set_sensitive(GetWidget("url"),TRUE);
	gtk_widget_set_sensitive(GetWidget("genre"),TRUE);
	gtk_widget_set_sensitive(GetWidget("desc"),TRUE);
	gtk_widget_set_sensitive(GetWidget("public"),TRUE);
	gtk_widget_set_sensitive(GetWidget("mp3"),TRUE);
	gtk_widget_set_sensitive(GetWidget("ogg"),TRUE);
	gtk_widget_set_sensitive(GetWidget("bitrate"),TRUE);
	gtk_widget_set_sensitive(GetWidget("title"),FALSE);
	gtk_window_set_title(GTK_WINDOW(win),"Cast test");
}

void StartClicked(GtkButton *obj, gpointer data)
{
	if (!rchan)
		Start();
	else
		Stop();
}

void TitleChanged(GtkEditable *obj, gpointer data)
{
	BASS_Encode_CastSetTitle(encoder,gtk_entry_get_text(GTK_ENTRY(obj)),NULL);
}

gboolean TimerProc(gpointer data)
{
	// draw the level bar
	static DWORD level=0;
	level=level>1500?level-1500:0;
	if (rchan) {
		DWORD l=BASS_ChannelGetLevel(rchan); // get current level
		if (LOWORD(l)>level) level=LOWORD(l);
		if (HIWORD(l)>level) level=HIWORD(l);
	}
	gtk_progress_set_percentage(GTK_PROGRESS(GetWidget("level")),level/32768.0);
	if (rchan) { // check number of listeners
		static int updatelisten=0;
		if (!(++updatelisten%100)) { // only checking once every 5 seconds
			char text[50];
			const char *stats;
			int listeners=0;
			if (stats=BASS_Encode_CastGetStats(encoder,BASS_ENCODE_STATS_ICE,NULL)) {
				char *t=strcasestr(stats,"<Listeners>"); // Icecast listener count
				if (t) listeners=atoi(t+11);
			} else if (stats=BASS_Encode_CastGetStats(encoder,BASS_ENCODE_STATS_SHOUT,NULL)) {
				char *t=strstr(stats,"<CURRENTLISTENERS>"); // Shoutcast listener count
				if (t) listeners=atoi(t+18);
			} else return TRUE;
			sprintf(text,"Cast test (%d listeners)",listeners);
			gtk_window_set_title(GTK_WINDOW(win),text);
		}
	}
	return TRUE;
}

int main(int argc, char* argv[])
{
#if !GLIB_CHECK_VERSION(2,32,0)
	g_thread_init(NULL);
#endif
	gdk_threads_init();
	gtk_init(&argc,&argv);

	// check the correct BASS was loaded
	if (HIWORD(BASS_GetVersion())!=BASSVERSION) {
		Error("An incorrect version of BASS was loaded");
		return 0;
	}

	// initialize default recording device
	if (!BASS_RecordInit(-1)) {
		Error("Can't initialize device");
		return 0;
	}

	// initialize GUI
	glade=glade_xml_new(GLADE_PATH"cast.glade",NULL,NULL);
	if (!glade) return 0;
	win=GetWidget("window1");
	if (!win) return 0;
	glade_xml_signal_autoconnect(glade);

	{
		GtkComboBox *list=GTK_COMBO_BOX(GetWidget("bitrate"));
		int c;
		for (c=0;c<14;c++) {
			char temp[10];
			sprintf(temp,"%d",bitrates[c]);
			gtk_combo_box_append_text(list,temp);
		}
		gtk_combo_box_set_active(list,8); // default bitrate = 128kbps
	}

	g_timeout_add(50,TimerProc,NULL);

	gdk_threads_enter();
	gtk_main();
	gdk_threads_leave();

	// release all BASS stuff
	BASS_RecordFree();

    return 0;
}
